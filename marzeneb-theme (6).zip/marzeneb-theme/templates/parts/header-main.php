<header class="site-header">
    <div class="container">
        <?php the_custom_logo(); ?>
    </div>
</header>
