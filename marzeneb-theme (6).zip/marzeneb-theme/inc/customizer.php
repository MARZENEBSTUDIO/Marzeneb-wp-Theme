<?php
// Add all sections in the WordPress Customizer

/**
 * Enqueue theme customizer script for live preview
 */

// Apply Customizer Setting
function marzeneb_customizer_css() {
    ?>
    <style>
        header {
            background-color: <?php echo get_theme_mod('header_background_color', '#ffffff'); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'marzeneb_customizer_css');
function marzeneb_customize_live_preview() {
    wp_enqueue_script(
        'marzeneb-customizer',
        get_template_directory_uri() . '/assets/js/customizer.js',
        ['jquery', 'customize-preview'],
        null,
        true
    );
}
add_action('customize_preview_init', 'marzeneb_customize_live_preview');

/**
 * Register Customizer Settings
 */
function marzeneb_customize_register($wp_customize) {
    // -------- GLOBAL SETTINGS --------
    $wp_customize->add_section('marzeneb_global_section', [
        'title' => __('Global Settings', 'marzeneb'),
        'description' => __('Customize global settings like typography, colors, and container width.', 'marzeneb'),
        'priority' => 10,
    ]);

    // Typography Settings
    $wp_customize->add_setting('marzeneb_typography_body', [
        'default' => 'Arial, sans-serif',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('marzeneb_typography_body_control', [
        'label' => __('Body Font', 'marzeneb'),
        'section' => 'marzeneb_global_section',
        'type' => 'text',
    ]);

    // Primary Color
    $wp_customize->add_setting('marzeneb_primary_color', [
        'default' => '#0073e6',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'marzeneb_primary_color_control',
            [
                'label' => __('Primary Color', 'marzeneb'),
                'section' => 'marzeneb_global_section',
                'settings' => 'marzeneb_primary_color',
            ]
        )
    );

    // Container Width
    $wp_customize->add_setting('marzeneb_container_width', [
        'default' => 1200,
        'sanitize_callback' => 'absint',
    ]);
    $wp_customize->add_control('marzeneb_container_width_control', [
        'label' => __('Container Width (px)', 'marzeneb'),
        'section' => 'marzeneb_global_section',
        'type' => 'number',
        'input_attrs' => [
            'min' => 960,
            'max' => 1920,
            'step' => 10,
        ],
    ]);

    // -------- HEADER SETTINGS --------
    $wp_customize->add_section('marzeneb_header_section', [
        'title' => __('Header Settings', 'marzeneb'),
        'priority' => 20,
    ]);

    // Logo
    $wp_customize->add_setting('marzeneb_logo', [
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'marzeneb_logo_control',
            [
                'label' => __('Logo Upload', 'marzeneb'),
                'section' => 'marzeneb_header_section',
                'settings' => 'marzeneb_logo',
            ]
        )
    );

    // Sticky Header
    $wp_customize->add_setting('marzeneb_sticky_header', [
        'default' => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ]);
    $wp_customize->add_control('marzeneb_sticky_header_control', [
        'label' => __('Enable Sticky Header', 'marzeneb'),
        'section' => 'marzeneb_header_section',
        'type' => 'checkbox',
    ]);

    // Header Background
    $wp_customize->add_setting('marzeneb_header_bg', [
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'marzeneb_header_bg_control',
            [
                'label' => __('Header Background Color', 'marzeneb'),
                'section' => 'marzeneb_header_section',
                'settings' => 'marzeneb_header_bg',
            ]
        )
    );

    // -------- FOOTER SETTINGS --------
    $wp_customize->add_section('marzeneb_footer_section', [
        'title' => __('Footer Settings', 'marzeneb'),
        'priority' => 30,
    ]);

    // Footer Background Color
    $wp_customize->add_setting('marzeneb_footer_bg', [
        'default' => '#000000',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'marzeneb_footer_bg_control',
            [
                'label' => __('Footer Background Color', 'marzeneb'),
                'section' => 'marzeneb_footer_section',
                'settings' => 'marzeneb_footer_bg',
            ]
        )
    );

    // Copyright Text
    $wp_customize->add_setting('marzeneb_copyright_text', [
        'default' => __('&copy; 2024 Your Company Name', 'marzeneb'),
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('marzeneb_copyright_text_control', [
        'label' => __('Copyright Text', 'marzeneb'),
        'section' => 'marzeneb_footer_section',
        'type' => 'text',
    ]);

    // Additional sections can be added similarly...
}
add_action('customize_register', 'marzeneb_customize_register');







?>
<?php
