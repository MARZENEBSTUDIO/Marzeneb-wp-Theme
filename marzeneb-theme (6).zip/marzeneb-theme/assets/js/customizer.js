(function ($) {
    wp.customize('marzeneb_menu_bg_color', function (value) {
        value.bind(function (newValue) {
            $('.main-navigation').css('background-color', newValue);
        });
    });

    wp.customize('marzeneb_menu_link_color', function (value) {
        value.bind(function (newValue) {
            $('.main-navigation a').css('color', newValue);
        });
    });

    wp.customize('marzeneb_menu_font_size', function (value) {
        value.bind(function (newValue) {
            $('.main-navigation a').css('font-size', newValue);
        });
    });
})(jQuery);
(function ($) {
    wp.customize('marzeneb_container_width', function (value) {
        value.bind(function (newValue) {
            $('.site-container').css('max-width', newValue + 'px');
        });
    });

    wp.customize('marzeneb_sidebar_position', function (value) {
        value.bind(function (newValue) {
            if (newValue === 'none') {
                $('.site-sidebar').hide();
            } else {
                $('.site-sidebar').show();
                $('.site-container').css('flex-direction', newValue === 'left' ? 'row-reverse' : 'row');
            }
        });
    });

    // Add similar live preview bindings for other settings
})(jQuery);
(function ($) {
    wp.customize('marzeneb_primary_color', function (value) {
        value.bind(function (newValue) {
            $('body').css('color', newValue);
        });
    });
    wp.customize('marzeneb_header_bg', function (value) {
        value.bind(function (newValue) {
            $('.site-header').css('background-color', newValue);
        });
    });
})(jQuery);
