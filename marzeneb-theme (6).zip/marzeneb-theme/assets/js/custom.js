// custom.js file for Marzeneb Theme

// Document Ready Function (Ensures DOM is fully loaded before executing JavaScript)
jQuery(document).ready(function($) {

    // Example: Bootstrap Modal Auto-show functionality
    if ($('#autoModal').length) {
        $('#autoModal').modal('show');
    }

    // Custom Scroll to Top Button
    var scrollButton = $('<button class="scroll-to-top">↑</button>').appendTo('body');
    scrollButton.hide(); // Initially hide the button
    
    // Show button when scrolling down
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            scrollButton.fadeIn();
        } else {
            scrollButton.fadeOut();
        }
    });
    
    // Smooth scroll to top
    scrollButton.click(function() {
        $('html, body').animate({ scrollTop: 0 }, 800);
        return false;
    });

    // Custom Bootstrap Dropdown Hover Effect
    $('.dropdown').hover(function() {
        $(this).addClass('show');
        $(this).children('.dropdown-menu').addClass('show');
    }, function() {
        $(this).removeClass('show');
        $(this).children('.dropdown-menu').removeClass('show');
    });

    // Custom Modal Close Event (For when a modal closes, perform some action)
    $('#myModal').on('hidden.bs.modal', function () {
        alert('Modal Closed');
    });

    // Example of a Sticky Navbar
    var stickyNav = $('.navbar');
    var stickyNavTop = stickyNav.offset().top;

    $(window).scroll(function() {
        if ($(window).scrollTop() > stickyNavTop) {
            stickyNav.addClass('sticky');
        } else {
            stickyNav.removeClass('sticky');
        }
    });

    // Add a fade-in effect to images
    $('img').on('load', function() {
        $(this).addClass('fade-in');
    });

    // Example of a Tooltip Initialization
    $('[data-toggle="tooltip"]').tooltip();

    // Example of a Custom Animation for Elements
    $('.animate-me').each(function() {
        var element = $(this);
        $(window).scroll(function() {
            if (element.offset().top - $(window).scrollTop() < $(window).height()) {
                element.addClass('fade-in-animation');
            }
        });
    });
});
// custom.js file for Marzeneb Theme

jQuery(document).ready(function($) {
    // Smooth Scroll for Anchors
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top
            }, 1000);
        }
    });

    // Toggle Class for Navbar on Scroll
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('scrolled');
        } else {
            $('.navbar').removeClass('scrolled');
        }
    });
});
function marzeneb_enqueue_scripts() {
    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), null, 'all');
    
    // Enqueue jQuery (if not already included by WordPress)
    wp_enqueue_script('jquery');
    
    // Enqueue Popper.js (needed for Bootstrap JS components like tooltips and popovers)
    wp_enqueue_script('popper', 'https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js', array('jquery'), null, true);
    
    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery', 'popper'), null, true);

    // Enqueue Custom JS
    wp_enqueue_script('marzeneb-custom-js', get_template_directory_uri() . '/js/custom.js', array('jquery', 'bootstrap-js'), null, true);
}
add_action('wp_enqueue_scripts', 'marzeneb_enqueue_scripts');
